from flask import Flask,request,jsonify
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)

svm_model = joblib.load("model_artifacts/one_class_svm_model.pkl")
scaler = joblib.load("model_artifacts/standard_scaler.pkl")
label_encoders = joblib.load("model_artifacts/label_encoder.pkl")
ordinal_encoder = joblib.load("model_artifacts/ordinal_encoder.pkl")
iso_forest = joblib.load("model_artifacts/iso_forest_model.pkl")

expected_columns = [
    'Country', 'Year', 'Attack Type', 'Target Industry',
    'Financial Loss (in Million $)', 'Number of Affected Users',
    'Attack Source', 'Security Vulnerability Type',
    'Defense Mechanism Used', 'Incident Resolution Time (in Hours)'
]

categorical_cols = [
    'Country', 'Attack Type', 'Target Industry',
    'Attack Source', 'Security Vulnerability Type',
    'Defense Mechanism Used'
]

@app.route('/')
def start():
    return "home page found"

@app.route('/predict',methods = ['POST'])
def predict():
      data = request.json

      if not all(col in data for col in expected_columns):
            return jsonify({"error":"missing input fields"}),400
      
      df = pd.DataFrame([data])

    #   for col in label_encoders:
    #         if col in df:
    #             encoder = label_encoders[col]
    #             df[col] = encoder.transform([df[col][0]])

      df[categorical_cols] = ordinal_encoder.transform(df[categorical_cols])

      X = df[expected_columns].values
      X_scaled = scaler.transform(X)

      prediction = int(iso_forest.predict(X_scaled)[0])
      

      res =  "Anomoly" if prediction == -1 else "Normal" 

      print("result of input is: ", res)

      return jsonify({
            "prediction" : prediction,
            "label": "Anomoly" if prediction == -1 else "Normal"
      }),400       

if __name__ == "__main__":
        app.run(debug = True)